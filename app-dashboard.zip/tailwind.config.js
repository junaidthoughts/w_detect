module.exports = {
  content: [
    "./src/**/*.{css,js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
