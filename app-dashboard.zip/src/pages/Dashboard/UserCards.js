import React from 'react'

const UserCards = () => {
  return (
    <div className='space-y-3'>
        <div className='py-5 px-4 bg-white bg-opacity-20 rounded-lg'>
            <img src="/images/profile.png" className='w-[80px]'/>
        </div>
        <div className='py-5 px-4 bg-white bg-opacity-20 rounded-lg'>
            <img src="/images/profile.png" className='w-[80px]'/>
        </div>
        <div className='py-5 px-4 bg-white bg-opacity-20 rounded-lg'>
            <img src="/images/profile.png" className='w-[80px]'/>
        </div>

    </div>
  )
}

export default UserCards